package com.example.multipagesetup

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    private lateinit var secondActivityBtn: Button
    private lateinit var ActivityBtn2: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        secondActivityBtn = findViewById(R.id.secondActivityBtn)

        secondActivityBtn.setOnClickListener {
            val intent = Intent(this, Activity2::class.java)//force import
            startActivity(intent)
        }
    }
}