package com.example.timerwithmp

import android.os.Bundle
import android.os.CountDownTimer
import android.widget.TextView
import android.widget.Toolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.example.timerwithmp.databinding.ActivityMainBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import me.zhanghai.android.materialprogressbar.MaterialProgressBar
import util.prefutil


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private lateinit var play: FloatingActionButton
    private lateinit var pause: FloatingActionButton
    private lateinit var reset: FloatingActionButton
    private lateinit var progress_bar: MaterialProgressBar
    private lateinit var text_home: TextView

    enum class TimerState{
        Stopped, Paused, Running
    }

    private lateinit var timer: CountDownTimer
    private var timerLengthSeconds: Long = 0L
    private var timerState = TimerState.Stopped

    private var secondsRemaining =0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        play = findViewById(R.id.fab_start)
        pause = findViewById(R.id.fab_stop)
        reset = findViewById(R.id.fab_reset)
        progress_bar = findViewById(R.id.progress_bar)
        text_home = findViewById(R.id.text_home)

        val navView: BottomNavigationView = binding.navView

        val navController = findNavController(R.id.nav_host_fragment_activity_main)
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        val appBarConfiguration = AppBarConfiguration(
            setOf(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications
            )
        )
        setupActionBarWithNavController(navController, appBarConfiguration)
        navView.setupWithNavController(navController)

        play.setOnClickListener{ v ->
            startTimer()
            timerState = TimerState.Running
            updateButtons()
        }

        pause.setOnClickListener { v ->
            timer.cancel()
            timerState = TimerState.Paused
            updateButtons()
        }

        reset.setOnClickListener { v ->
            timer.cancel()
            onTimerFinished()
        }
    }

    override fun onResume() {
        super.onResume()

        initTimer()
    }

    fun OnPause() {
        super.onPause()

        if (timerState == TimerState.Running){
            timer.cancel()
        }
        else if (timerState == TimerState.Paused){

        }

        prefutil.setPreviousTimerLengthSeoncds(timerLengthSeconds, this)
        prefutil.setSecondsRemaining(secondsRemaining, this)
        prefutil.setTimerState(timerState, this)
    }

    private fun initTimer(){
        timerState = prefutil.getTimerState(this)

        if (timerState == TimerState.Stopped)
            setNewTimerLength()
        else
            setPreviousTimerLength()

        secondsRemaining = if (timerState == TimerState.Running || timerState == TimerState.Paused)
            prefutil.getSecondsRemaining(this)
        else
            timerLengthSeconds

        if(timerState == TimerState.Running)
            startTimer()

        updateButtons()
        updateCountdownUI()
    }

    private fun onTimerFinished(){
        timerState = TimerState.Stopped

        setNewTimerLength()

        progress_bar.progress = 0

        prefutil.setSecondsRemaining(timerLengthSeconds, this)
        secondsRemaining = timerLengthSeconds

        updateButtons()
        updateCountdownUI()

    }

    private fun startTimer(){
        timerState = TimerState.Running
        timer = object : CountDownTimer(secondsRemaining * 1000, 1000){
            override fun onFinish() = onTimerFinished()

            override fun onTick(millisUntilFinished: Long){
                secondsRemaining = millisUntilFinished / 1000
                updateCountdownUI()
            }
        }.start()
    }

    private fun setNewTimerLength(){
        val lengthInMinutes = prefutil.getTimerLength(this)
        timerLengthSeconds = (lengthInMinutes * 60L)
        progress_bar.max = timerLengthSeconds.toInt()
    }

    private fun setPreviousTimerLength(){
        timerLengthSeconds = prefutil.getPreviousTimerLengthSeconds(this)
        progress_bar.max = timerLengthSeconds.toInt()
    }

    private fun updateCountdownUI(){
        val minutesUntilFinished = secondsRemaining / 60
        val secondsInMinutesUntilFinished = secondsRemaining - minutesUntilFinished * 60
        val secondsStr = secondsInMinutesUntilFinished.toString()
        text_home.text = "$minutesUntilFinished:${
            if (secondsStr.length == 2) secondsStr
        else "0" + secondsStr}"
        progress_bar.progress = (timerLengthSeconds - secondsRemaining).toInt()

    }

    private fun updateButtons(){
        when(timerState){
            TimerState.Running ->{
                play.isEnabled = false
                pause.isEnabled = true
                reset.isEnabled = true
            }
            TimerState.Stopped ->{
                play.isEnabled = true
                pause.isEnabled = false
                reset.isEnabled = false
            }
            TimerState.Paused ->{
                play.isEnabled = true
                pause.isEnabled = false
                reset.isEnabled = true
            }
        }
    }
}